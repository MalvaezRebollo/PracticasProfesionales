﻿Public Class Inicio
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim salir As String = MsgBox("¿Deseas salir?", vbYesNo, "¿Salir?")

        If salir = vbYes Then
            Me.Close()
        End If
    End Sub

    Private Sub UsuarioBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles UsuarioBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.UsuarioBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.FermalDataSet)

    End Sub

    Private Sub Inicio_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'FermalDataSet.usuario' Puede moverla o quitarla según sea necesario.
        Me.UsuarioTableAdapter.Fill(Me.FermalDataSet.usuario)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Validate()
        UsuarioBindingSource.Filter = "usuario='" & TextBox1.Text & "' AND  contraseña= '" & TextBox2.Text & " ' "

        If UsuarioBindingSource.Count = 1 Then
            MsgBox("Bienvenido " & TextBox1.Text & "!!!")
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox1.Focus()
            Me.Hide()
            Form2.Show()

        Else
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox1.Focus()
            MsgBox("Error! No coinciden los datos", MsgBoxStyle.Critical, "Error de logeo")

        End If
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            TextBox2.Focus()
        End If
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            Button1.PerformClick()
        End If
    End Sub
End Class
