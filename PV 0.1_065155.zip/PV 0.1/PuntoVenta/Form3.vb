﻿Public Class Form3
    Public Property PrintForm3 As Object

    Private Sub Cantidad_TextChanged(sender As Object, e As EventArgs) Handles Cantidad.TextChanged

    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        Cantidad.Text = Module1.NOM
        producto.Text = Module1.NOM1



    End Sub
    Private Sub Printform()
        PrintForm3.Print()

    End Sub
    Private Sub Print1()
        If PrintDialog.ShowDialog = DialogResult.OK Then
            PrintForm3.PrinterSettings = PrintDialog.PrinterSettings
            PrintForm3.Print()

        End If
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Button1.Visible = False
        Print1()
        Button1.Visible = True
    End Sub

    Private Sub producto_TextChanged(sender As Object, e As EventArgs) Handles producto.TextChanged

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
End Class