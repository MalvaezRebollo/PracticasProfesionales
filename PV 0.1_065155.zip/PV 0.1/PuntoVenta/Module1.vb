﻿Module Module1
    Public NOM As Double
    Public NOM1 As String





End Module
