﻿
Imports System.Data
Imports System.Data.OleDb



Public Class Form2

    Dim con As New OleDbConnection
    Dim sql As New OleDbCommand
    Dim consulta As String = ""
    Dim dr As OleDbDataAdapter
    Dim ord As DataSet
    Dim busca As Byte
    Private Sub ProductosBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.ProductosBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.FermalDataSet1)

    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cerrado()


        Timer1.Start()
        Timer2.Start()

        Try
            con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Jorge Malvaez\source\repos\PuntoVenta\PuntoVenta\bin\Debug\Fermal.accdb"
            con.Open()
            MsgBox(" Conexion satisfactoria", MsgBoxStyle.Information, "Aviso")
        Catch ex As Exception
            MsgBox("Error de conexión", vbCritical, "Aviso")
        End Try




        'TODO: esta línea de código carga datos en la tabla 'FermalDataSet1.Productos' Puede moverla o quitarla según sea necesario.
        Me.ProductosTableAdapter.Fill(Me.FermalDataSet1.Productos)

    End Sub

    Private Sub IdLabel_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ImagenPictureBox_Click(sender As Object, e As EventArgs) Handles ImagenPictureBox.Click
        Try
            OpenFileDialog1.Title = "Abrir Imagen"
            OpenFileDialog1.FileName = ".jpg"
            OpenFileDialog1.Filter = "All files |*.*"
            OpenFileDialog1.ShowDialog()
            ImagenPictureBox.Image = System.Drawing.Image.FromFile(OpenFileDialog1.FileName)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        abierto()
        Me.Validate()
        Me.ProductosBindingSource.AddNew()
        CódigoTextBox.Focus()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        If ImagenPictureBox.Image Is Nothing Or CódigoTextBox.Text = "" Or ProductoTextBox.Text = "" Or DescripciónTextBox.Text = "" Or PrecioTextBox.Text = "" Or ExistenciaTextBox.Text = "" Then
            MsgBox("Error! Debes llenar todos los coampos de la izquierda con la imagen", MsgBoxStyle.Critical, "Falló la captura")
        Else
            If ProductosBindingSource.Find("Código", CódigoTextBox.Text) = -1 Then
                Me.Validate()
                Me.ProductosBindingSource.EndEdit()
                Me.TableAdapterManager.UpdateAll(Me.FermalDataSet1)
                Me.ProductosTableAdapter.Fill(Me.FermalDataSet1.Productos)
                MsgBox("Bien! ya agregaste el producto", MsgBoxStyle.Information, "ok Captura")
                cerrado()
                TextBox1.Focus()
            Else
                CódigoTextBox.Text = ""
                CódigoTextBox.Focus()

                MsgBox("No puedes agregar ese código porque ya existe, revisa de nuevo", MsgBoxStyle.Critical, "Falla de Captura")
            End If


        End If

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        If CódigoTextBox.Text = "" Then
            MsgBox("No hay ningún producto para eliminar", MsgBoxStyle.Critical, "Error al eliminar")
        Else
            Dim eliminar As String = MsgBox(" ¿Quieres eliminar el producto seleccionado? ", vbYesNo, "¿Eliminar?")
            If eliminar = vbYes Then
                Me.Validate()
                Me.ProductosBindingSource.RemoveCurrent()
                Me.TableAdapterManager.UpdateAll(Me.FermalDataSet1)
                Me.ProductosTableAdapter.Fill(Me.FermalDataSet1.Productos)
                MsgBox("Bien!, ya eliminaste el producto", MsgBoxStyle.Information, "Codigo eliminado")
            Else
                MsgBox("Se ha cancelado la eliminación del código", MsgBoxStyle.Information, "Acción cancelada")

            End If
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Me.Validate()
        Me.ProductosTableAdapter.Fill(Me.FermalDataSet1.Productos)
        MsgBox("La acción ha sido cancelada, no se guardó el código", MsgBoxStyle.Information, "Acción cancelada")
        cerrado()
        TextBox1.Focus()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If CódigoTextBox.Enabled = False Then
            abierto()
        Else
            Me.Validate()
            Me.ProductosBindingSource.EndEdit()
            Me.TableAdapterManager.UpdateAll(Me.FermalDataSet1)
            Me.ProductosTableAdapter.Fill(Me.FermalDataSet1.Productos)
            MsgBox("El producto ha sido editado satisfactoriamente", MsgBoxStyle.Information, "Código editado")
            cerrado()
            TextBox1.Focus()
        End If



    End Sub


    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Me.ProductosBindingSource.MoveFirst()

    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Me.ProductosBindingSource.MovePrevious()

    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Me.ProductosBindingSource.MoveNext()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.ProductosBindingSource.MoveLast()
    End Sub



    Private Sub Buscar_Click(sender As Object, e As EventArgs) Handles Buscar.Click

        Try
            If TextBox1.Text = "" Then
                Exit Sub

            Else
                Dim buscador As String = TextBox1.Text
                ProductosBindingSource.Filter = "(Código ='" & TextBox1.Text & "')"


                If ProductosBindingSource.Count <> 0 Then
                    ProductosDataGridView.DataSource = ProductosBindingSource
                Else
                    MsgBox("El código " & buscador & "no existe")
                    ProductosBindingSource.Filter = Nothing
                    ProductosDataGridView.ClearSelection()
                    ProductosDataGridView.DataSource = ProductosBindingSource
                End If
                TextBox1.Focus()
            End If
        Catch ex As Exception
            MsgBox(" Error número " & Err.Number & vbNewLine & " deDescripción del error: " & Err.Description)
        End Try
    End Sub

    Private Sub Bunom_Click(sender As Object, e As EventArgs) Handles Bunom.Click
        Try
            If TextBox1.Text = "" Then
                Exit Sub

            Else
                Dim buscador As String = TextBox1.Text
                ProductosBindingSource.Filter = "(Producto ='" & TextBox1.Text & "')"


                If ProductosBindingSource.Count <> 0 Then
                    ProductosDataGridView.DataSource = ProductosBindingSource
                Else
                    MsgBox("El producto " & buscador & "no existe")
                    ProductosBindingSource.Filter = Nothing
                    ProductosDataGridView.ClearSelection()
                    ProductosDataGridView.DataSource = ProductosBindingSource
                End If
                TextBox1.Focus()
            End If
        Catch ex As Exception
            MsgBox(" Error número " & Err.Number & vbNewLine & " deDescripción del error: " & Err.Description)
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label1.Text = TimeOfDay

    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Label2.Text = DateString
    End Sub



    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            Dim cantidad As String
            Dim validar As Boolean

            validar = False
            cantidad = InputBox("Agregar la cantidad del producto", "Cantidad", 0)
            If IsNumeric(cantidad) Then



                If cantidad > ExistenciaTextBox.Text Then
                    MsgBox("Error! la cantidad ingresada es mayor a la existencia", MsgBoxStyle.Critical, "Error en cantidad")
                    TextBox1.Text = ""
                    TextBox1.Focus()
                    ProductosDataGridView.Refresh()
                Else
                    Dim actulizarex As Integer
                    Dim costot As Double = cantidad * PrecioTextBox.Text
                    actulizarex = ExistenciaTextBox.Text - cantidad
                    ExistenciaTextBox.Text = actulizarex
                    ListBox1.Items.Add(ProductoTextBox.Text)
                    ListBox2.Items.Add(PrecioTextBox.Text & "x" & cantidad)
                    ListBox3.Items.Add(costot)
                    TextBox1.Text = ""

                    actulizarex = ExistenciaTextBox.Text - cantidad

                    Validate()
                    Me.ProductosBindingSource.EndEdit()
                    Me.TableAdapterManager.UpdateAll(Me.FermalDataSet1)
                    Me.ProductosTableAdapter.Fill(FermalDataSet1.Productos)
                    ProductosDataGridView.Refresh()
                    TextBox1.Text = ""

                    validar = False
                    Dim suma As Double

                    For Each elemento In ListBox3.Items
                        suma += elemento.ToString
                    Next
                    TextBox2.Text = suma
                    TextBox1.Focus()

                End If
            Else
                MsgBox("Error! sólo se aceptan números, no letras", MsgBoxStyle.Critical, "No válido")

            End If

        End If
    End Sub

    Public Sub exportar_excel(ByVal dgv As DataGridView, ByVal pth As String)
        Dim xlapp As Object = CreateObject("Excel.application")

        Dim xlWB As Object = xlapp.WorkBooks.add
        Dim xlWS As Object = xlWB.WorkSheets(1)

        For c As Integer = 0 To ProductosDataGridView.Columns.Count - 1
            xlWS.Cells(1, c + 1).value = ProductosDataGridView.Columns(c).HeaderText

        Next
        For r As Integer = 0 To ProductosDataGridView.RowCount - 1
            For c As Integer = 0 To ProductosDataGridView.Columns.Count - 1
                xlWS.Cells(r + 2, c + 1).value = ProductosDataGridView.Item(c, r).Value
            Next

        Next
        xlWB.saveas(pth)
        xlWS = Nothing
        xlWB = Nothing
        xlapp.quit()
        xlapp = Nothing


    End Sub

    Private Sub cerrado()
        ImagenPictureBox.Enabled = False
        CódigoTextBox.Enabled = False
        ProductoTextBox.Enabled = False
        DescripciónTextBox.Enabled = False
        PrecioTextBox.Enabled = False
        ExistenciaTextBox.Enabled = False
        Button3.Enabled = False
        ProductosDataGridView.Enabled = False


    End Sub

    Private Sub habilitartabla()
        ProductosDataGridView.Enabled = True


    End Sub
    Private Sub abierto()
        ImagenPictureBox.Enabled = True
        CódigoTextBox.Enabled = True
        ProductoTextBox.Enabled = True
        DescripciónTextBox.Enabled = True
        PrecioTextBox.Enabled = True
        ExistenciaTextBox.Enabled = True
        Button3.Enabled = True


    End Sub
    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Dim pago As String
        Dim validar As Boolean
        validar = False
        pago = InputBox("ingresa el pago", "Pago", 0)

        If IsNumeric(pago) Then

            Dim cambio As Double
            Dim suma As Double

            For Each elemento In ListBox3.Items
                suma += elemento.ToString
            Next
            cambio = pago - suma

            TextBox2.Text = suma
            TextBox3.Text = pago
            TextBox4.Text = cambio
        Else
            MsgBox("Error! la cantidad que ingresaste no es número", MsgBoxStyle.Critical, "No válido")
        End If




    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click

        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""

        TextBox1.Focus()


    End Sub

    Private Sub MENUToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MENUToolStripMenuItem.Click

    End Sub

    Private Sub CerrarSesiónToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CerrarSesiónToolStripMenuItem.Click
        Inicio.Show()
        Me.Close()

    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        Dim save As New SaveFileDialog
        save.Filter = "Archivos Excel |.xlsx"
        If save.ShowDialog = Windows.Forms.DialogResult.OK Then
            exportar_excel(Me.ProductosDataGridView, save.FileName)

        End If
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Module1.NOM = TextBox2.Text
        Module1.NOM1 = ProductoTextBox.Text

        TextBox1.Focus()
        Form3.Show()


    End Sub

    Private Sub CódigoTextBox_TextChanged(sender As Object, e As EventArgs) Handles CódigoTextBox.TextChanged

    End Sub

    Private Sub ProductoTextBox_TextChanged(sender As Object, e As EventArgs) Handles ProductoTextBox.TextChanged

    End Sub

    Private Sub DescripciónTextBox_TextChanged(sender As Object, e As EventArgs) Handles DescripciónTextBox.TextChanged

    End Sub

    Private Sub PrecioTextBox_TextChanged(sender As Object, e As EventArgs) Handles PrecioTextBox.TextChanged

    End Sub

    Private Sub ExistenciaTextBox_TextChanged(sender As Object, e As EventArgs) Handles ExistenciaTextBox.TextChanged

    End Sub

    Private Sub CódigoTextBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles CódigoTextBox.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            ProductoTextBox.Focus()
        End If
    End Sub

    Private Sub ProductoTextBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ProductoTextBox.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            DescripciónTextBox.Focus()
        End If
    End Sub

    Private Sub DescripciónTextBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles DescripciónTextBox.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            PrecioTextBox.Focus()
        End If
    End Sub

    Private Sub PrecioTextBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles PrecioTextBox.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            ExistenciaTextBox.Focus()
        End If
    End Sub

    Private Sub ExistenciaTextBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ExistenciaTextBox.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            Button3.PerformClick()
        End If
    End Sub


End Class